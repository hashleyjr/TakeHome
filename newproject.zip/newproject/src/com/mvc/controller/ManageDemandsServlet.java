package com.mvc.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvc.dao.ReservationDao;

/**
 * Servlet implementation class ManageDemandsServlet
 */
@WebServlet("/ManageDemandsServlet")
public class ManageDemandsServlet extends HttpServlet {
 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int choice = Integer.parseInt(request.getParameter("choice"));
		int booking = Integer.parseInt(request.getParameter("booking"));
		
		if (choice==0) {
			ReservationDao.deleteBooking(booking);
			request.setAttribute("message", "You deleted the request");
			request.getRequestDispatcher("/demands.jsp").forward(request, response);
			
		}
		if (choice==1) {
			int house = Integer.parseInt(request.getParameter("house_id"));
			ReservationDao.validateBooking(booking,house);
			ReservationDao.validateBooking2(booking,house);
			request.setAttribute("message", "You validated the request");
			request.getRequestDispatcher("/demands.jsp").forward(request, response);
			
		}
		
	}
}
