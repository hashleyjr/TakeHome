package com.mvc.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvc.dao.BookingDao;
import com.mvc.bean.BookingBean;

/**
 * Servlet implementation class GetBooking
 */
@WebServlet("/BookingTesting")
public class Booking extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String todate = request.getParameter("todate");
		String fromdate = request.getParameter("fromdate");
		int owner = Integer.parseInt(request.getParameter("owner"));
		int house = Integer.parseInt(request.getParameter("house"));
		int renter = Integer.parseInt(request.getParameter("renter"));
		
		BookingBean booking = new BookingBean();
		
		booking.setTodate(todate);
		booking.setFromdate(fromdate); 
		booking.setOwner(owner); 
		booking.setRenter(renter); 	
		booking.setHouse(house); 	
		
		BookingDao bookingD = new BookingDao(); //creating object for LoginDao. This class contains main logic of the application.
		 
		String tobook = bookingD.book(booking);
		if(tobook.equals("Booked! Wait for the owner to validate this trip.")) //If function returns success string then user will be rooted to Home page
		{
			request.setAttribute("errMessage", tobook); 
			request.getRequestDispatcher("/houseprofile.jsp").forward(request, response);//RequestDispatcher is used to send the control to the invoked page.
		}
		else
		{
		request.setAttribute("errMessage", tobook); //If authenticateUser() function returnsother than SUCCESS string it will be sent to Login page again. Here the error message returned from function has been stored in a errMessage key.
		request.getRequestDispatcher("/houseprofile.jsp").forward(request, response);//forwarding the request
		}
	}

}
