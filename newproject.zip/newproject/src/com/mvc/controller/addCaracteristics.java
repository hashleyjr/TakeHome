package com.mvc.controller;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/**
 * Servlet implementation class addCaracteristics
 */
@MultipartConfig (maxFileSize=16177216) // jusuqu'à 16 MB
public class addCaracteristics extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	PrintWriter out;
		
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
			
			String connectionURL = "jdbc:mysql://localhost:3306/test";
			String user = "root";
			String pass = "";
			out = response.getWriter();
			int result = 0;
			Connection con = null;
			String resultMessage = "";
			
			String title = request.getParameter("title");
			String type = request.getParameter("type");
			String address = request.getParameter("address");
			int zip = Integer.parseInt(request.getParameter("zip"));
			String city = request.getParameter("city");
			String country = request.getParameter("country");
			int distanceToCenter = Integer.parseInt(request.getParameter("distanceToCenter"));
			int maxCapacity = Integer.parseInt(request.getParameter("maxCapacity"));
			int beds = Integer.parseInt(request.getParameter("beds"));
			String isSmokingAllowed = request.getParameter("smoking");
			String isNoiseAfter11Allowed = request.getParameter("noise");
			String isPetsAllowed = request.getParameter("pet");
			String description = request.getParameter("description");
			Part part1 = request.getPart("image1");
			Part part2 = request.getPart("image2");
			Part part3 = request.getPart("image3");
			int user_id = Integer.parseInt(request.getParameter("user_id"));
			// nom de l'image dans la textbox
			 // nom de la textbox
			
			if (title != null && part1 != null ) {
				
				try {
					Class.forName("com.mysql.jdbc.Driver");
					con = DriverManager.getConnection(connectionURL, user, pass);
					PreparedStatement ps = con.prepareStatement("insert into house (title,type,"
							+ "address,zip,city,country,distanceToCenter"
							+ ",maxCapacity,beds,isSmokingAllowed,isNoiseAfter11Allowed,isPetsAllowed,"
							+ "Description,image1,image2,image3,bookable,user_id)"
							+ "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
					InputStream is1 = part1.getInputStream();
					InputStream is2 = part2.getInputStream();
					InputStream is3 = part3.getInputStream();
					
					ps.setString(1, title);
					ps.setString(2, type);
					ps.setString(3, address);
					ps.setInt(4, zip);
					ps.setString(5, city);
					ps.setString(6, country);
					ps.setInt(7, distanceToCenter);
					ps.setInt(8, maxCapacity);
					ps.setInt(9, beds);
					ps.setString(10, isSmokingAllowed);
					ps.setString(11, isNoiseAfter11Allowed);
					ps.setString(12, isPetsAllowed);
					ps.setString(13,description);
					ps.setBlob(14, is1);
					ps.setBlob(15, is2);
					ps.setBlob(16, is3);
					ps.setInt(17, 1);
					ps.setInt(18, user_id);
					result = ps.executeUpdate();
					if (result > 0) {
						System.out.println("image inserted successfully");
						request.setAttribute("message", "Your house has been added to our database");
						request.getRequestDispatcher("/addHouse.jsp").forward(request, response);
					}
				}
				catch(Exception e) {
					out.println(e);
				}
			}
			
		}
		



	}