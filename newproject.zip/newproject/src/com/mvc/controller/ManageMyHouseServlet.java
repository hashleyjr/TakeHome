package com.mvc.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvc.bean.HouseBean;
import com.mvc.dao.HouseDao;

/**
 * Servlet implementation class ManageMyHouseServlet
 */
@WebServlet("/ManageMyHouseServlet")
public class ManageMyHouseServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int choice = Integer.parseInt(request.getParameter("choice"));
		
		
		if (choice==0) {
			int id = Integer.parseInt(request.getParameter("id"));
			HouseDao.deleteHouse(id);
			request.setAttribute("message", "You deleted your house");
			request.getRequestDispatcher("/myhouse.jsp").forward(request, response);
			
		}
		if (choice==1) {
			int id = Integer.parseInt(request.getParameter("house_id"));
			request.setAttribute("house", id);
			request.getRequestDispatcher("/editHouse.jsp").forward(request, response);
			
		}
		
	}
}
