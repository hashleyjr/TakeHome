package com.mvc.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mvc.bean.UserB;
import com.mvc.dao.UserDao;


@WebServlet("/LoginServletTesting")

public class LoginServlet extends HttpServlet {
 
public LoginServlet() {
 }
 
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
 
//Here username and password are the names which I have given in the input box in Login.jsp page. Here I am retrieving the values entered by the user and keeping in instance variables for further use.
 
String userName = request.getParameter("username");
String password = request.getParameter("password");
 
UserB loginBean = new UserB(); //creating object for LoginBean class, which is a normal java class, contains just setters and getters. Bean classes are efficiently used in java to access user information wherever required in the application.
 
loginBean.setemail(userName); //setting the username and password through the loginBean object then only you can get it in future.
 loginBean.setpassword(password);
 
UserDao loginDao = new UserDao(); //creating object for LoginDao. This class contains main logic of the application.
 int[] userValidate = UserDao.authenticateUser(loginBean); //Calling authenticateUser function
 
if(userValidate[0] !=0 && userValidate[1]==0)//he is in the database + not an admin
 {
 loginBean.setId(userValidate[0]);
 HttpSession session = request.getSession(true);	
 session.setAttribute("login",loginBean.getemail());
 session.setAttribute("id",loginBean.getId());
 request.getRequestDispatcher("/index.jsp").forward(request, response);//RequestDispatcher is used to send the control to the invoked page.
 }
if (userValidate[0] !=0 && userValidate[1]==1) { //he is in the databse + admin
	 loginBean.setId(userValidate[0]);
	 HttpSession session = request.getSession(true);	
	 session.setAttribute("login",loginBean.getemail());
	 session.setAttribute("id",loginBean.getId());
	 session.setAttribute("admin",1);
	 request.getRequestDispatcher("/viewusers.jsp").forward(request, response);//RequestDispatcher is used to send the control to the invoked page.
}
 else 
 {
 request.setAttribute("errMessage", "Invalid credentials"); //If authenticateUser() function returnsother than SUCCESS string it will be sent to Login page again. Here the error message returned from function has been stored in a errMessage key.
 request.getRequestDispatcher("/login.jsp").forward(request, response);//forwarding the request
 }
 }
 
}