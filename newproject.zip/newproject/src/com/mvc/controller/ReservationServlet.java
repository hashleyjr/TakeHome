package com.mvc.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvc.dao.HouseDao;
import com.mvc.dao.ReservationDao;


/**
 * Servlet implementation class Reservation
 */
@WebServlet("/ReservationServlet")
public class ReservationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ReservationServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int renter = Integer.parseInt(request.getParameter("renter"));
		ReservationDao reservationD = new ReservationDao();
		ArrayList list = reservationD.retrieveReservations(renter);
		if (list.isEmpty()!=true) {
			request.setAttribute("list", list);
			request.setAttribute("message","You have access to all reservations you made");
			 request.getRequestDispatcher("/reservations.jsp").forward(request, response);//RequestDispatcher is used to send the control to the invoked page.
			 
			 }else {
				
				 request.setAttribute("message", "You haven't made any reservations yet");
				 request.getRequestDispatcher("/reservations.jsp").forward(request, response);
			 }
	}
	

	
	


}
