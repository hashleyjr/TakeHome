package com.mvc.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvc.bean.HouseBean;
import com.mvc.dao.HouseDao;

/**
 * Servlet implementation class GetHouseProfileServlet
 */
@WebServlet("/GetHouseProfileServlet")
public class GetHouseProfileServlet extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int house_id = Integer.parseInt(request.getParameter("id"));
		HouseBean houseBean = new HouseBean();
		houseBean.setHouseID(house_id);
		
		HouseDao houseDao = new HouseDao();
		

		ArrayList list = houseDao.retrieveHouseProfile(houseBean);
		if (list.isEmpty()!=true) {
		request.setAttribute("list", list);
		request.getRequestDispatcher("/houseprofile.jsp").forward(request, response);//RequestDispatcher is used to send the control to the invoked page.
		 
		 }
		else {
			System.out.println("Nothing");
		}
	}

}
