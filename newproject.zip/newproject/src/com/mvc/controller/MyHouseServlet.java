package com.mvc.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvc.dao.HouseDao;
import com.mvc.bean.HouseBean;

/**
 * Servlet implementation class MyHouseServlet
 */
@WebServlet("/MyHouseServlet")
public class MyHouseServlet extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("owner");
		
		HouseBean houseBean = new HouseBean();
		houseBean.setUser_id(Integer.parseInt(id));
		
		HouseDao houseDao = new HouseDao();
		

		ArrayList list = houseDao.retrieveMyHouse(houseBean);
		if (list.isEmpty()!=true) {
		request.setAttribute("list", list);
		 request.setAttribute("message", "You have access to all the houses you added on your account");
		 request.getRequestDispatcher("/myhouse.jsp").forward(request, response);//RequestDispatcher is used to send the control to the invoked page.
		 
		}else {
			 request.setAttribute("message", "You don't have any houses for the moment");
			 request.getRequestDispatcher("/myhouse.jsp").forward(request, response);
		 

		}
	}
	
	 
}
