package com.mvc.controller;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/**
 * Servlet implementation class modifyCaracteristics
 */

@MultipartConfig (maxFileSize=16177216)
public class modifyCaracteristics extends HttpServlet {
	private static final long serialVersionUID = 1L;
	PrintWriter out;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		
	String connectionURL = "jdbc:mysql://localhost:3306/test";
	String user = "root";
	String pass = "";
	out = response.getWriter();
	int result = 0;
	Connection con = null;
	String resultMessage = "";
	
	
	
	String title = request.getParameter("title");
	String type = request.getParameter("type");
	String address = request.getParameter("address");
	int zip = Integer.parseInt(request.getParameter("zip"));
	String city = request.getParameter("city");
	String country = request.getParameter("country");
	int distanceToCenter = Integer.parseInt(request.getParameter("distanceToCenter"));
	int maxCapacity = Integer.parseInt(request.getParameter("maxCapacity"));
	int beds = Integer.parseInt(request.getParameter("beds"));
	String isSmokingAllowed = request.getParameter("smoking");
	String isNoiseAfter11Allowed = request.getParameter("noise");
	String isPetsAllowed = request.getParameter("pet");
	String description = request.getParameter("description");
	Part part1 = request.getPart("image1");
	Part part2 = request.getPart("image2");
	Part part3 = request.getPart("image3");
	int houseID = Integer.parseInt(request.getParameter("house_id"));
	InputStream is1 = part1.getInputStream();
	InputStream is2 = part2.getInputStream();
	InputStream is3 = part3.getInputStream();
	String i1 = request.getParameter("i1");
	String i2 = request.getParameter("i2");
	String i3 = request.getParameter("i3");
	

	// nom de l'image dans la textbox
	 // nom de la textbox
	
	if (i1 == null && i2 == null && i3 == null) {
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(connectionURL, user, pass);
			PreparedStatement ps = con.prepareStatement(  
					"update house set title=?, type=?, address=?, zip=?, city=?, country=?, distanceToCenter=?,"
							+ "maxCapacity=?, beds=?, isSmokingAllowed=?, isNoiseAfter11Allowed=?, isPetsAllowed=?,"
							+ "Description=? where house_id=?");
							       			
			
			
			ps.setString(1, title);
			ps.setString(2, type);
			ps.setString(3, address);
			ps.setInt(4, zip);
			ps.setString(5, city);
			ps.setString(6, country);
			ps.setInt(7, distanceToCenter);
			ps.setInt(8, maxCapacity);
			ps.setInt(9, beds);
			ps.setString(10, isSmokingAllowed);
			ps.setString(11, isNoiseAfter11Allowed);
			ps.setString(12, isPetsAllowed);
			ps.setString(13,description);
			
			ps.setInt(14, houseID);
			
			result = ps.executeUpdate();
			if (result > 0) {
				request.getRequestDispatcher("/index.jsp").forward(request, response);
				
			}
	
		}
		catch(Exception e) {
			out.println(e);
		}
	
	}
	else if (i2 == null && i3 == null ){
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(connectionURL, user, pass);
			PreparedStatement ps = con.prepareStatement(  
					"update house set title=?, type=?, address=?, zip=?, city=?, country=?, distanceToCenter=?,"
							+ "maxCapacity=?, beds=?, isSmokingAllowed=?, isNoiseAfter11Allowed=?, isPetsAllowed=?,"
							+ "Description=?, image1=? where house_id=?");
							       			
			
			
			ps.setString(1, title);
			ps.setString(2, type);
			ps.setString(3, address);
			ps.setInt(4, zip);
			ps.setString(5, city);
			ps.setString(6, country);
			ps.setInt(7, distanceToCenter);
			ps.setInt(8, maxCapacity);
			ps.setInt(9, beds);
			ps.setString(10, isSmokingAllowed);
			ps.setString(11, isNoiseAfter11Allowed);
			ps.setString(12, isPetsAllowed);
			ps.setString(13,description);
			ps.setBlob(14, is1);
	
			ps.setInt(15, houseID);
			
			result = ps.executeUpdate();
			if (result > 0) {
				request.getRequestDispatcher("/index.jsp").forward(request, response);
				
			}
	
		}
		catch(Exception e) {
			out.println(e);
		}
	}
else if (i1 == null && i3 == null ){
	try {
		Class.forName("com.mysql.jdbc.Driver");
		con = DriverManager.getConnection(connectionURL, user, pass);
		PreparedStatement ps = con.prepareStatement(  
				"update house set title=?, type=?, address=?, zip=?, city=?, country=?, distanceToCenter=?,"
						+ "maxCapacity=?, beds=?, isSmokingAllowed=?, isNoiseAfter11Allowed=?, isPetsAllowed=?,"
						+ "Description=?, image2=? where house_id=?");
						       			
		
		
		ps.setString(1, title);
		ps.setString(2, type);
		ps.setString(3, address);
		ps.setInt(4, zip);
		ps.setString(5, city);
		ps.setString(6, country);
		ps.setInt(7, distanceToCenter);
		ps.setInt(8, maxCapacity);
		ps.setInt(9, beds);
		ps.setString(10, isSmokingAllowed);
		ps.setString(11, isNoiseAfter11Allowed);
		ps.setString(12, isPetsAllowed);
		ps.setString(13,description);
		ps.setBlob(14, is2);
	

		ps.setInt(15, houseID);
		
		result = ps.executeUpdate();
		if (result > 0) {
			request.getRequestDispatcher("/index.jsp").forward(request, response);
			
		}

	}
	catch(Exception e) {
		out.println(e);
	}
	}
else if (i1 == null && i2 == null ){
	try {
		Class.forName("com.mysql.jdbc.Driver");
		con = DriverManager.getConnection(connectionURL, user, pass);
		PreparedStatement ps = con.prepareStatement(  
				"update house set title=?, type=?, address=?, zip=?, city=?, country=?, distanceToCenter=?,"
						+ "maxCapacity=?, beds=?, isSmokingAllowed=?, isNoiseAfter11Allowed=?, isPetsAllowed=?,"
						+ "Description=?, image3=? where house_id=?");
						       			
		
		
		ps.setString(1, title);
		ps.setString(2, type);
		ps.setString(3, address);
		ps.setInt(4, zip);
		ps.setString(5, city);
		ps.setString(6, country);
		ps.setInt(7, distanceToCenter);
		ps.setInt(8, maxCapacity);
		ps.setInt(9, beds);
		ps.setString(10, isSmokingAllowed);
		ps.setString(11, isNoiseAfter11Allowed);
		ps.setString(12, isPetsAllowed);
		ps.setString(13,description);
		ps.setBlob(14, is3);
	

		ps.setInt(15, houseID);
		
		result = ps.executeUpdate();
		if (result > 0) {
			request.getRequestDispatcher("/index.jsp").forward(request, response);
			
		}

	}
	catch(Exception e) {
		out.println(e);
	}
}
else if (i1 == null ){
	try {
		Class.forName("com.mysql.jdbc.Driver");
		con = DriverManager.getConnection(connectionURL, user, pass);
		PreparedStatement ps = con.prepareStatement(  
				"update house set title=?, type=?, address=?, zip=?, city=?, country=?, distanceToCenter=?,"
						+ "maxCapacity=?, beds=?, isSmokingAllowed=?, isNoiseAfter11Allowed=?, isPetsAllowed=?,"
						+ "Description=?, image2=?, image3=? where house_id=?");
						       			
		
		
		ps.setString(1, title);
		ps.setString(2, type);
		ps.setString(3, address);
		ps.setInt(4, zip);
		ps.setString(5, city);
		ps.setString(6, country);
		ps.setInt(7, distanceToCenter);
		ps.setInt(8, maxCapacity);
		ps.setInt(9, beds);
		ps.setString(10, isSmokingAllowed);
		ps.setString(11, isNoiseAfter11Allowed);
		ps.setString(12, isPetsAllowed);
		ps.setString(13,description);
		ps.setBlob(14, is2);
		ps.setBlob(15, is3);
		ps.setInt(16, houseID);
		
		result = ps.executeUpdate();
		if (result > 0) {
			request.getRequestDispatcher("/index.jsp").forward(request, response);
			
		}

	}
	catch(Exception e) {
		out.println(e);
	}
}
else if (i2 == null ){
	try {
		Class.forName("com.mysql.jdbc.Driver");
		con = DriverManager.getConnection(connectionURL, user, pass);
		PreparedStatement ps = con.prepareStatement(  
				"update house set title=?, type=?, address=?, zip=?, city=?, country=?, distanceToCenter=?,"
						+ "maxCapacity=?, beds=?, isSmokingAllowed=?, isNoiseAfter11Allowed=?, isPetsAllowed=?,"
						+ "Description=?, image1=?, image3=? where house_id=?");
						       			
		
		
		ps.setString(1, title);
		ps.setString(2, type);
		ps.setString(3, address);
		ps.setInt(4, zip);
		ps.setString(5, city);
		ps.setString(6, country);
		ps.setInt(7, distanceToCenter);
		ps.setInt(8, maxCapacity);
		ps.setInt(9, beds);
		ps.setString(10, isSmokingAllowed);
		ps.setString(11, isNoiseAfter11Allowed);
		ps.setString(12, isPetsAllowed);
		ps.setString(13,description);
		ps.setBlob(14, is1);
		ps.setBlob(15, is3);

		ps.setInt(16, houseID);
		
		result = ps.executeUpdate();
		if (result > 0) {
			request.getRequestDispatcher("/index.jsp").forward(request, response);
			
		}

	}
	catch(Exception e) {
		out.println(e);
	}
}
else if (i3 == null ){
	try {
		Class.forName("com.mysql.jdbc.Driver");
		con = DriverManager.getConnection(connectionURL, user, pass);
		PreparedStatement ps = con.prepareStatement(  
				"update house set title=?, type=?, address=?, zip=?, city=?, country=?, distanceToCenter=?,"
						+ "maxCapacity=?, beds=?, isSmokingAllowed=?, isNoiseAfter11Allowed=?, isPetsAllowed=?,"
						+ "Description=?, image1=?, image2=? where house_id=?");
						       			
		
		
		ps.setString(1, title);
		ps.setString(2, type);
		ps.setString(3, address);
		ps.setInt(4, zip);
		ps.setString(5, city);
		ps.setString(6, country);
		ps.setInt(7, distanceToCenter);
		ps.setInt(8, maxCapacity);
		ps.setInt(9, beds);
		ps.setString(10, isSmokingAllowed);
		ps.setString(11, isNoiseAfter11Allowed);
		ps.setString(12, isPetsAllowed);
		ps.setString(13,description);
		ps.setBlob(14, is1);
		ps.setBlob(15, is2);
		ps.setInt(16, houseID);
		
		result = ps.executeUpdate();
		if (result > 0) {
			request.getRequestDispatcher("/index.jsp").forward(request, response);
			
		}

	}
	catch(Exception e) {
		out.println(e);
	}
}
else {
	try {
		Class.forName("com.mysql.jdbc.Driver");
		con = DriverManager.getConnection(connectionURL, user, pass);
		PreparedStatement ps = con.prepareStatement(  
				"update house set title=?, type=?, address=?, zip=?, city=?, country=?, distanceToCenter=?,"
						+ "maxCapacity=?, beds=?, isSmokingAllowed=?, isNoiseAfter11Allowed=?, isPetsAllowed=?,"
						+ "Description=?, image1=?, image2=?, image3=? where house_id=?");
						       			
		
		
		ps.setString(1, title);
		ps.setString(2, type);
		ps.setString(3, address);
		ps.setInt(4, zip);
		ps.setString(5, city);
		ps.setString(6, country);
		ps.setInt(7, distanceToCenter);
		ps.setInt(8, maxCapacity);
		ps.setInt(9, beds);
		ps.setString(10, isSmokingAllowed);
		ps.setString(11, isNoiseAfter11Allowed);
		ps.setString(12, isPetsAllowed);
		ps.setString(13,description);
		ps.setBlob(14, is1);
		ps.setBlob(15, is2);
		ps.setBlob(16, is3);
		ps.setInt(17, houseID);
		
		result = ps.executeUpdate();
		if (result > 0) {
			request.getRequestDispatcher("/index.jsp").forward(request, response);
			
		}

	}
	catch(Exception e) {
		out.println(e);
	}
}
}

}
