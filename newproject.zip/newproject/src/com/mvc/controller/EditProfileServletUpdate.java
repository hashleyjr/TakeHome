package com.mvc.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvc.bean.UserB;
import com.mvc.dao.UserDao;

/**
 * Servlet implementation class EditProfileServletUpdate
 */
@WebServlet("/EditProfileServletUpdate")
public class EditProfileServletUpdate extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int choice =Integer.parseInt(request.getParameter("choice"));
		int id = Integer.parseInt(request.getParameter("id"));
		String firstname = request.getParameter("firstname");
		String lastname = request.getParameter("lastname");
		String email = request.getParameter("email");
		String tel = request.getParameter("tel");
		
		UserB u = new UserB();
		
		u.setId(id);
		u.setfirstname(firstname);
		u.setlastname(lastname);
		u.setemail(email); 
		u.settel(tel);
		
		UserDao.update(u, id);
		if (choice==1) { //changes made by the admin
			request.getRequestDispatcher("/viewusers.jsp").forward(request, response);
		}
		if (choice==0) {
			request.setAttribute("message", "Your profile has been edited");
			request.getRequestDispatcher("/EditProfile.jsp").forward(request, response);
		}
	}

}
