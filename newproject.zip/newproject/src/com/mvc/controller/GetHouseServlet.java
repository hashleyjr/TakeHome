package com.mvc.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvc.dao.HouseDao;

import com.mvc.bean.HouseBean;

/**
 * Servlet implementation class GetHouseServlet
 */
@WebServlet("/GetHouseServletTesting")
public class GetHouseServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public GetHouseServlet() {
    }


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String city = request.getParameter("city");
		if (city.length()!=0) {
		HouseBean houseBean = new HouseBean();
		houseBean.setCity(city);
		
		HouseDao houseDao = new HouseDao();
		

		ArrayList list = houseDao.retrieveHouse(houseBean);
		if (list.isEmpty()!=true) {
		request.setAttribute("list", list);
		 request.setAttribute("message", "The lodgings available...");
		 request.getRequestDispatcher("/house.jsp").forward(request, response);//RequestDispatcher is used to send the control to the invoked page.
		 
		 }else {
			 request.setAttribute("message", "Sorry we don't have any lodging in this city");
			 request.getRequestDispatcher("/house.jsp").forward(request, response);
		 }
		}
		else {
			HouseDao houseDao = new HouseDao();
			ArrayList list = houseDao.retrieveAllHouse();
			if (list.isEmpty()!=true) {
				request.setAttribute("list", list);
				 request.setAttribute("message", "The lodgings available...");
				 request.getRequestDispatcher("/house.jsp").forward(request, response);//RequestDispatcher is used to send the control to the invoked page.
				 
				 }else {
					 request.setAttribute("message", "Sorry we don't have any lodging");
					 request.getRequestDispatcher("/house.jsp").forward(request, response);
				 }
		}
	}
	
}


