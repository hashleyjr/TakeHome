package com.mvc.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.mvc.bean.HouseBean;
import com.mvc.dao.CommentDao;
import com.mvc.dao.HouseDao;
import com.mvc.dao.UserDao;
import com.mvc.bean.Comment;

/**
 * Servlet implementation class CommentServlet
 */
@WebServlet("/CommentServlet")
public class CommentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			CommentDao commentDao = new CommentDao();
			int user_id =  Integer.parseInt(request.getParameter("user_id"));
			String comment2 = request.getParameter("comment");
			int house_id2 = Integer.parseInt(request.getParameter("house_id"));
			String message = commentDao.putComment(user_id, house_id2, comment2);
			request.setAttribute("errMessage", message);
			request.getRequestDispatcher("/commentAdded.jsp").forward(request, response);
			
		}
	

}
