package com.mvc.bean;

import javax.servlet.annotation.WebServlet;

@WebServlet("/BookingBean")
public class BookingBean {
	private int bookindID;
	private static int house;
    private static int owner;
    private static int renter;
    private static String todate;
    private String fromdate;
    
	public String getFromdate() {
		return fromdate;
	}
	public void setFromdate(String fromdate) {
		this.fromdate = fromdate;
	}
	public static String getTodate() {
		return todate;
	}
	public static void setTodate(String todate) {
		BookingBean.todate = todate;
	}
	public static int getRenter() {
		return renter;
	}
	public void setRenter(int renter) {
		BookingBean.renter = renter;
	}
	public static int getOwner() {
		return owner;
	}
	public static void setOwner(int owner) {
		BookingBean.owner = owner;
	}
	public int getBookindID() {
		return bookindID;
	}
	public void setBookindID(int bookindID) {
		this.bookindID = bookindID;
	}
	public static int getHouse() {
		return house;
	}
	public static void setHouse(int house) {
		BookingBean.house = house;
	}

}