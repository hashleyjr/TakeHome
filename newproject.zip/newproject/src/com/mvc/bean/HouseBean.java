package com.mvc.bean;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/**
 * Servlet implementation class House
 */
@WebServlet("/HouseBean")

public class HouseBean {
private int houseID;
private String title;
private String description;
private String address;
private String country;
private String type;
private int zip;
private String city;
private int distanceToCenter;
private String IsPetsAllowed;
private String IsSmokingAllowed;
private int maxcapacity;
private int beds;
private String IsNoiseAfter11Allowed;
private int bookable;
private int user_id;
private String image1;
private String image2;
private String image3;

public String getTitle() {
	return title;
}
public void setTitle(String title) {
	this.title = title;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getCountry() {
	return country;
}
public void setCountry(String country) {
	this.country = country;
}
public String getType() {
	return type;
}
public void setType(String isHouse) {
	this.type = isHouse;
}
public int getZip() {
	return zip;
}
public void setZip(int zip) {
	this.zip = zip;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public int getDistanceToCenter() {
	return distanceToCenter;
}
public void setDistanceToCenter(int distanceToCenter) {
	this.distanceToCenter = distanceToCenter;
}
public String getIsSmokingAllowed() {
	return IsSmokingAllowed;
}
public void setIsSmokingAllowed(String isSmokingAllowed) {
	this.IsSmokingAllowed = isSmokingAllowed;
}
public String getIsPetsAllowed() {
	return IsPetsAllowed;
}
public void setIsPetsAllowed(String isPetsAllowed) {
	this.IsPetsAllowed = isPetsAllowed;
}
public int getMaxcapacity() {
	return maxcapacity;
}
public void setMaxcapacity(int maxcapacity) {
	this.maxcapacity = maxcapacity;
}
public int getBeds() {
	return beds;
}
public void setBeds(int beds) {
	this.beds = beds;
}
public String getIsNoiseAfter11Allowed() {
	return IsNoiseAfter11Allowed;
}
public void setIsNoiseAfter11Allowed(String isNoiseAfter11Allowed) {
	this.IsNoiseAfter11Allowed = isNoiseAfter11Allowed;
}
public int getBookable() {
	return bookable;
}
public void setBookable(int bookable) {
	this.bookable = bookable;
}
public int getHouseID() {
	return houseID;
}
public void setHouseID(int houseID) {
	this.houseID = houseID;
}
public int getUser_id() {
	return user_id;
}
public void setUser_id(int user_id) {
	this.user_id = user_id;
}
public String getImage1() {
	return image1;
}
public void setImage1(String image1) {
	this.image1 = image1;
}
public String getImage2() {
	return image2;
}
public void setImage2(String image2) {
	this.image2 = image2;
}
public String getImage3() {
	return image3;
}
public void setImage3(String image3) {
	this.image3 = image3;
}
}

