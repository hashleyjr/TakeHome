package com.mvc.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvc.bean.BookingBean;
import com.mvc.util.DBconnection;

/**
 * Servlet implementation class BookingD
 */
@WebServlet("/BookingDao")
public class BookingDao extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
	public static Connection getConnection(){  
	    Connection con=null; 
	   
	    try{  
	        Class.forName("com.mysql.jdbc.Driver");  
	        con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","");  
	    }catch(Exception e){System.out.println(e);}  
	    return con;  
	}  
	
	public static String book(BookingBean b){  
		 int status=0;
		try{  
	        Connection con=getConnection();
	        
	        PreparedStatement ps=con.prepareStatement(  
	"insert into booking(house_id,fromdate,todate,renter,owner,validate) values(?,?,?,?,?,?)");  
	        ps.setInt(1,b.getHouse());  
	        ps.setString(2,b.getFromdate());  
	        ps.setString(3,b.getTodate());  
	        ps.setInt(4,b.getRenter());  
	        ps.setInt(5,b.getOwner());  
	        ps.setInt(6,0);  
	        status=ps.executeUpdate();  
	    }catch(Exception e){return "The inputs are invalids, try again";}  
	    return "Booked! Wait for the owner to validate this trip.";  
	}  
	

}
