package com.mvc.dao;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Base64;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvc.bean.HouseBean;
import com.mvc.bean.Comment;
import com.mvc.util.DBconnection;


/**
 * Servlet implementation class HouseD
 */
@WebServlet("/CommentDao")
public class CommentDao extends HttpServlet {
private static final long serialVersionUID = 1L;  
	
	
	 public ArrayList<Comment> retrieveComments(Comment comment) throws IOException {
		 
		 	ArrayList<Comment> v = new ArrayList<Comment>();
		 	int house_id = comment.getHouseID();
			Connection con = null;
			Statement statement = null;
			 ResultSet rs = null;
			try
			 {
			 con = DBconnection.createConnection(); //establishing connection
			 String searchQuery = "SELECT * FROM comments JOIN user ON user.user_id=comments.id_user WHERE id_house ='" + house_id + "'";
			 PreparedStatement ps = con.prepareStatement(searchQuery);
			 rs = ps.executeQuery();
			 if (rs.next()== false) {
				 return v;
			 } else {
				 do {
					 Comment comments = new Comment();
					 comments.setCommentID(rs.getInt("id_comments"));
					 comments.setUserID(rs.getInt("id_user"));
					 comments.setComment(rs.getString("text"));
					 comments.setName(rs.getString("lastname"));
					 comments.setFirstname(rs.getString("firstname"));
					 
					 v.add(comments);
				 } while (rs.next());
			 }
			}
			 catch(SQLException e)
			 {
			 e.printStackTrace();
			 }
			return v;	 
	 } public boolean hasBooked(int id,int house) throws IOException {
		 
		 	ArrayList<Comment> v = new ArrayList<Comment>();
		 	
			Connection con = null;
			Statement statement = null;
			 ResultSet rs = null;
			try
			 {
			 con = DBconnection.createConnection(); //establishing connection
			 PreparedStatement st = con.prepareStatement("SELECT * FROM booking WHERE renter = ? AND house_id= ?");
		     st.setInt(1, id);
		     st.setInt(2, house);
		     rs=st.executeQuery();
		     if (rs.next()== false) {
				 return false;
			 } else {
				 do {
					return true;
				 } while (rs.next());
			 }
			}
			 catch(SQLException e)
			 {
			 e.printStackTrace();
			 }
			return false;	 
	 }
		public String putComment(int user_id, int house_id, String comment) {
		    int status=0;  
		    System.out.println(house_id);
		    System.out.println(user_id);
		    System.out.println(comment);
		    try{  
		        Connection con=DBconnection.createConnection();
		        PreparedStatement ps=con.prepareStatement(  
		        		"insert into comments(text,id_house,id_user) values(?,?,?)");  
		        		        ps.setString(1,comment);  
		        		        ps.setInt(3,user_id);  
		        		        ps.setInt(2,house_id); 
		        		        status=ps.executeUpdate();        	              
		    }catch(Exception e){System.out.println(e);}  
			return "Your message was successfully added !";
		}
}

