package com.mvc.dao;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Base64;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvc.bean.HouseBean;
import com.mvc.util.DBconnection;

/**
 * Servlet implementation class HouseD
 */
@WebServlet("/HouseDao")
public class HouseDao extends HttpServlet {
private static final long serialVersionUID = 1L;  
	
	public String getImage(Blob blob) throws SQLException, IOException {
		 InputStream inputStream = blob.getBinaryStream();
         ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
         byte[] buffer = new byte[4096];
         int bytesRead = -1;
             
         while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);                  
            }
             
         byte[] imageBytes = outputStream.toByteArray();
         String base64Image = Base64.getEncoder().encodeToString(imageBytes);
         return base64Image;
	}
	 public ArrayList<HouseBean> retrieveHouse(HouseBean houseB)
	 {
		 
		ArrayList<HouseBean> v = new ArrayList<HouseBean>();
	 
		String city = houseB.getCity(); //Keeping user entered values in temporary variables.
		
		Connection con = null;
		Statement statement = null;
		 ResultSet rs = null;
		try
		 {
		 con = DBconnection.createConnection(); //establishing connection
		 String searchQuery = "select * from house where city ='" + city + "' and bookable = 1 ";
		 PreparedStatement ps = con.prepareStatement(searchQuery);
		 rs = ps.executeQuery();
		 if (rs.next()== false) {
			 return v;
		 } else {
			 do {
				 HouseBean houseBean = new HouseBean();
				 
				 int house_id = rs.getInt("house_id");
				 String title = rs.getString("title");
				 String address = rs.getString("address");
				 String description = rs.getString("description");
				 Blob blob = rs.getBlob("image1");
				 
				 String image = getImage(blob);
				
				 houseBean.setHouseID(house_id);
				 houseBean.setTitle(title);
				 houseBean.setAddress(address);
				 houseBean.setDescription(description);
				 houseBean.setImage1(image);
			 
				 v.add(houseBean);
			 } while (rs.next());
		 }
		}
		 catch(SQLException |IOException e)
		 {
		 e.printStackTrace();
		 }
		return v;
		 }
	 public ArrayList<HouseBean> retrieveAllHouse()
	 {
		 
		ArrayList<HouseBean> v = new ArrayList<HouseBean>();
		
		Connection con = null;
		Statement statement = null;
		 ResultSet rs = null;
		try
		 {
		 con = DBconnection.createConnection(); //establishing connection
		 String searchQuery = "select * from house where bookable = 1 ";
		 PreparedStatement ps = con.prepareStatement(searchQuery);
		 rs = ps.executeQuery();
		 if (rs.next()== false) {
			 return v;
		 } else {
			 do {
				 HouseBean houseBean = new HouseBean();
				 
				 int house_id = rs.getInt("house_id");
				 String title = rs.getString("title");
				 String address = rs.getString("address");
				 String description = rs.getString("description");
				 Blob blob = rs.getBlob("image1");
				 
				 String image = getImage(blob);
				 
				 houseBean.setHouseID(house_id);
				 houseBean.setTitle(title);
				 houseBean.setAddress(address);
				 houseBean.setDescription(description);
				 houseBean.setImage1(image);
			 
				 v.add(houseBean);
			 } while (rs.next());
		 }
		}
		 catch(SQLException|IOException e)
		 {
		 e.printStackTrace();
		 }
		return v;
		 }
	 
	 public ArrayList<HouseBean> retrieveHouseProfile(HouseBean houseB) throws IOException
	 {
		 
		ArrayList<HouseBean> v = new ArrayList<HouseBean>();
	 
		int house_id = houseB.getHouseID(); //Keeping user entered values in temporary variables.
		
		Connection con = null;
		Statement statement = null;
		 ResultSet rs = null;
		try
		 {
		 con = DBconnection.createConnection(); //establishing connection
		 String searchQuery = "SELECT * FROM house JOIN user ON user.user_id = house.user_id WHERE house_id ='" + house_id + "'";
		 PreparedStatement ps = con.prepareStatement(searchQuery);
		 rs = ps.executeQuery();
		 if (rs.next()== false) {
			 return v;
		 } else {
			 do {
				 HouseBean houseBean = new HouseBean();
				 houseBean.setHouseID(rs.getInt("house_id"));
				 houseBean.setTitle(rs.getString("title"));
				 houseBean.setCity(rs.getString("city"));
				 houseBean.setDescription(rs.getString("description"));
				 houseBean.setAddress(rs.getString("address"));
				 houseBean.setType(rs.getString("type"));
				 houseBean.setZip(rs.getInt("zip"));
				 houseBean.setCountry(rs.getString("country"));
				 houseBean.setDistanceToCenter(rs.getInt("distanceToCenter"));
				 houseBean.setIsPetsAllowed(rs.getString("IsPetsAllowed"));
				 houseBean.setIsSmokingAllowed(rs.getString("IsSmokingAllowed"));
				 houseBean.setMaxcapacity(rs.getInt("maxCapacity"));
				 houseBean.setBeds(rs.getInt("beds"));
				 houseBean.setIsNoiseAfter11Allowed(rs.getString("IsNoiseAfter11Allowed"));
				 houseBean.setBookable(rs.getInt("bookable"));
				 houseBean.setUser_id(rs.getInt("user_id"));
				 
				 Blob blob1 = rs.getBlob("image1");
				 String image1 = getImage(blob1);
				 houseBean.setImage1(image1);
				 Blob blob2 = rs.getBlob("image2");
				 String image2 = getImage(blob2);
				 houseBean.setImage2(image2);
				 Blob blob3 = rs.getBlob("image3");
				 String image3 = getImage(blob3);
				 houseBean.setImage3(image3);
				 
				 v.add(houseBean);
			 } while (rs.next());
		 }
		}
		 catch(SQLException e)
		 {
		 e.printStackTrace();
		 }
		return v;
		 }
	 public ArrayList<HouseBean> retrieveMyHouse(HouseBean houseB)
	 {
		 
		ArrayList<HouseBean> v = new ArrayList<HouseBean>();
		
		Connection con = null;
		Statement statement = null;
		 ResultSet rs = null;
		int id = houseB.getUser_id();
		try
		 {
		 con = DBconnection.createConnection(); //establishing connection
		 PreparedStatement st = con.prepareStatement("select * from house where user_id = ? ");
	     st.setInt(1, id);
	     rs=st.executeQuery();
		
		 if (rs.next()== false) {
			 return v;
		 } else {
			 do {
				 HouseBean houseBean = new HouseBean();
				 
				 int house_id = rs.getInt("house_id");
				 String title = rs.getString("title");
				 String address = rs.getString("address");
				 String description = rs.getString("description");
				 Blob blob = rs.getBlob("image1");
				 
				 String image = getImage(blob);
				 
				 houseBean.setHouseID(house_id);
				 houseBean.setTitle(title);
				 houseBean.setAddress(address);
				 houseBean.setDescription(description);
				 houseBean.setImage1(image);
			 
				 v.add(houseBean);
			 } while (rs.next());
		 }
		}
		 catch(SQLException|IOException e)
		 {
		 e.printStackTrace();
		 }
		return v;
		 } 
	 public static int deleteHouse(int id)
	 {
     	int status=0;
		Connection con = null;
		Statement statement = null;
		 ResultSet rs = null;
		try
		 {
		 con = DBconnection.createConnection(); //establishing connection
		 PreparedStatement ps=con.prepareStatement("delete from house where house_id=?");  
	        ps.setInt(1,id);  
	        status=ps.executeUpdate();  
		 }
		 catch(SQLException e)
			 {
			 e.printStackTrace();
			 }
		return status;
		 }
	 
	 public static HouseBean getHouseInfo(int id){  
		    HouseBean houseBean=null; 
		    
		    try{  
		        Connection con=DBconnection.createConnection();  
		        PreparedStatement ps=con.prepareStatement("select * from house where house_id=?");  
		        ps.setInt(1,id);  
		        ResultSet rs=ps.executeQuery();  
		        while(rs.next()){
						 houseBean = new HouseBean();
						 houseBean.setHouseID(rs.getInt("house_id"));
						 houseBean.setTitle(rs.getString("title"));
						 houseBean.setCity(rs.getString("city"));
						 houseBean.setDescription(rs.getString("description"));
						 houseBean.setAddress(rs.getString("address"));
						 houseBean.setType(rs.getString("type"));
						 houseBean.setZip(rs.getInt("zip"));
						 houseBean.setCountry(rs.getString("country"));
						 houseBean.setDistanceToCenter(rs.getInt("distanceToCenter"));
						 houseBean.setIsPetsAllowed(rs.getString("IsPetsAllowed"));
						 houseBean.setIsSmokingAllowed(rs.getString("IsSmokingAllowed"));
						 houseBean.setMaxcapacity(rs.getInt("maxCapacity"));
						 houseBean.setBeds(rs.getInt("beds"));
						 houseBean.setIsNoiseAfter11Allowed(rs.getString("IsNoiseAfter11Allowed"));
						 
						 houseBean.setBookable(rs.getInt("bookable"));
						 houseBean.setUser_id(rs.getInt("user_id"));
						 
					 } while (rs.next());
				 
				}
				 catch(SQLException e)
				 {
				 e.printStackTrace();
				 }
				return houseBean;
				 }
}

