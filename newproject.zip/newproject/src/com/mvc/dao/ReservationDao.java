package com.mvc.dao;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Base64;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvc.bean.HouseBean;
import com.mvc.util.DBconnection;

/**
 * Servlet implementation class ReservationD
 */
@WebServlet("/ReservationDao")
public class ReservationDao extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
    public static ArrayList<HouseBean> retrieveReservations(int renter) throws IOException
	 {
		 
		ArrayList<HouseBean> v = new ArrayList<HouseBean>();
	 
		
		Connection con = null;
		Statement statement = null;
		 ResultSet rs = null;
		try
		 {
		 con = DBconnection.createConnection(); //establishing connection
		 String searchQuery = "select * from house JOIN booking ON house.house_id = booking.house_id JOIN user ON user.user_id = booking.owner WHERE renter ='" + renter + "'";
		 PreparedStatement ps = con.prepareStatement(searchQuery);
		 rs = ps.executeQuery();
		 if (rs.next()==false) {
			 return v;
		 } else {
			 do {
				 HouseBean houseBean = new HouseBean();
				 houseBean.setTitle(rs.getString("title"));
				 houseBean.setDescription(rs.getString("description"));
				 houseBean.setBookable(rs.getInt("validate"));
				 houseBean.setHouseID(rs.getInt("house_id"));
				 houseBean.setAddress(rs.getString("fromdate"));
				 houseBean.setCountry(rs.getString("todate"));
				 houseBean.setType(rs.getString("firstname"));//owner first name & last name
				 houseBean.setCity(rs.getString("lastname"));
				 
				 Blob blob = rs.getBlob("image1");
				 
				 InputStream inputStream = blob.getBinaryStream();
			     ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			     byte[] buffer = new byte[4096];
			     int bytesRead = -1;
			            
			     while ((bytesRead = inputStream.read(buffer)) != -1) {
			               outputStream.write(buffer, 0, bytesRead);                  
			           }
			            
			     byte[] imageBytes = outputStream.toByteArray();
			     String base64Image = Base64.getEncoder().encodeToString(imageBytes);
				 
				 houseBean.setImage1(base64Image);
				 
				 v.add(houseBean);
			 } while (rs.next());
		 }
		}
		 catch(SQLException e)
			 {
			 e.printStackTrace();
			 }
		return v;
		 }
    public static ArrayList<HouseBean> retrieveDemands(int owner) throws IOException
	 {
		 
		ArrayList<HouseBean> v = new ArrayList<HouseBean>();
	 
		
		Connection con = null;
		Statement statement = null;
		 ResultSet rs = null;
		try
		 {
		 con = DBconnection.createConnection(); //establishing connection
		 String searchQuery = "select * from house JOIN booking ON house.house_id = booking.house_id JOIN user ON booking.renter = user.user_id  WHERE validate = 0 AND owner ='" + owner + "'";
		 PreparedStatement ps = con.prepareStatement(searchQuery);
		 rs = ps.executeQuery();
		 if (rs.next()==false) {
			 return v;
		 } else {
			 do {
				 HouseBean houseBean = new HouseBean();
				 houseBean.setTitle(rs.getString("title"));
				 houseBean.setDescription(rs.getString("description"));
				 houseBean.setBookable(rs.getInt("booking_id"));
				 houseBean.setHouseID(rs.getInt("house_id"));
				 houseBean.setAddress(rs.getString("fromdate"));
				 houseBean.setCountry(rs.getString("todate"));
				 houseBean.setType(rs.getString("firstname"));//renter first name & last name
				 houseBean.setCity(rs.getString("lastname"));
				 
				 Blob blob = rs.getBlob("image1");
				 
				 InputStream inputStream = blob.getBinaryStream();
			     ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			     byte[] buffer = new byte[4096];
			     int bytesRead = -1;
			            
			     while ((bytesRead = inputStream.read(buffer)) != -1) {
			               outputStream.write(buffer, 0, bytesRead);                  
			           }
			            
			     byte[] imageBytes = outputStream.toByteArray();
			     String base64Image = Base64.getEncoder().encodeToString(imageBytes);
				 
				 houseBean.setImage1(base64Image);
				 
				 v.add(houseBean);
			 } while (rs.next());
		 }
		}
		 catch(SQLException e)
			 {
			 e.printStackTrace();
			 }
		return v;
		 }
    public static int deleteBooking(int booking)
	 {
     	int status=0;
		Connection con = null;
		Statement statement = null;
		 ResultSet rs = null;
		try
		 {
		 con = DBconnection.createConnection(); //establishing connection
		 PreparedStatement ps=con.prepareStatement("delete from booking where booking_id=?");  
	        ps.setInt(1,booking);  
	        status=ps.executeUpdate();  
		 }
		 catch(SQLException e)
			 {
			 e.printStackTrace();
			 }
		return status;
		 }
    public static int validateBooking(int booking, int house)
  	 {
       	int status=0;
  		Connection con = null;
  		Statement statement = null;
  		 ResultSet rs = null;
  		try
  		 {
  		 con = DBconnection.createConnection(); //establishing connection
  		 PreparedStatement ps=con.prepareStatement("update booking set validate = ? where booking_id=?");  
  	        ps.setInt(1,1);
  	        ps.setInt(2,booking);
  	        status=ps.executeUpdate();  
  		 }
  		 catch(SQLException e)
  			 {
  			 System.out.println(e);
  			 }
  		return status;
  		 }
    public static int validateBooking2(int booking, int house)
 	 {
      	int status=0;
 		Connection con = null;
 		Statement statement = null;
 		 ResultSet rs = null;
 		try
 		 {
 		 con = DBconnection.createConnection(); //establishing connection
 	    PreparedStatement ps=con.prepareStatement("update house set bookable=? where house_id = ?");  
 	    ps.setInt(1,0);  
 	    ps.setInt(2,house);
 	    status=ps.executeUpdate();   
 		 }
 		 catch(SQLException e)
 			 {
 			 System.out.println(e);
 			 }
 		return status;
 		 }


}
