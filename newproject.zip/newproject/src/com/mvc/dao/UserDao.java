package com.mvc.dao;


import java.sql.*;  
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.annotation.WebServlet;

import com.mvc.util.DBconnection;
import com.mvc.bean.*;

import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import com.mvc.dao.*;



@WebServlet("/UserDao")
public class UserDao {
	public static Connection getConnection(){  
	    Connection con=null;  
	    try{  
	        Class.forName("com.mysql.jdbc.Driver");  
	        con=DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","");  
	    }catch(Exception e){System.out.println(e);}  
	    return con;  
	}  
	public static int[] authenticateUser(UserB loginBean)
	 {
	 
	String userName = loginBean.getemail(); //Keeping user entered values in temporary variables.
	 String password = loginBean.getpassword();
	int id=0;
	Connection con = null;
	 Statement statement = null;
	 ResultSet resultSet = null;
	 
	String userNameDB = "";
	 String passwordDB = "";
	 int admin;
	 int ar[] = new int[2];
	try
	 {
	 con = DBconnection.createConnection(); //establishing connection
	 statement = con.createStatement(); //Statement is used to write queries. Read more about it.
	 resultSet = statement.executeQuery("select email,password,user_id,admin from user"); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
	 
	
	while(resultSet.next()) // Until next row is present otherwise it return false
	 {
	  admin = resultSet.getInt("admin");
	  userNameDB = resultSet.getString("email"); //fetch the values present in database
	  passwordDB = resultSet.getString("password");
	  id =resultSet.getInt("user_id");
	   if(userName.equals(userNameDB) && password.equals(passwordDB))
	   {
		   ar[0]= id; // he is in the database
		   if(admin == 0) { // he is not an admin
		        ar[1] = 0;
		   }
		   else { 
			   ar[1] = 1;// he is an admin
		   }
		   return ar;
	   }
	   else { // he is not in the database
		   ar[0]=0;
		   ar[1]=0;
	   }
	 }
	} catch(SQLException e) {
	 e.printStackTrace();
	 } 
	 return ar;
	 }
	
	public static String registerUser(UserB u){  
		String email = u.getemail();
		
	    int status=0;  
	    try{  
	        Connection con=getConnection();
	        PreparedStatement st = con.prepareStatement("select * from user where email = ? ");
	        st.setString(1, email);
	        ResultSet r1=st.executeQuery();
	        if(r1.next()){
	        	 
	        	
	        	return "Email already exists"; 
	        	
	        	
	             
	        }
	        
	        PreparedStatement ps=con.prepareStatement(  
	"insert into user(firstname,lastname,email,tel,password,admin) values(?,?,?,?,?,?)");  
	        ps.setString(1,u.getfirstname());  
	        ps.setString(2,u.getlastname());  
	        ps.setString(3,u.getemail());  
	        ps.setString(4,u.gettel());   
	        ps.setString(5,u.getpassword());  
	        ps.setInt(6, 0);
	        status=ps.executeUpdate();  
	    }catch(Exception e){System.out.println(e);}  
	    return "SUCCESS";  
	}  
	
	public static int update(UserB u, int id){  
	    int status=0;  
	    try{  
	        Connection con=getConnection();  
	        PreparedStatement ps=con.prepareStatement(  
	"update user set firstname=?,lastname=?,email=?,tel=? where user_id=?");  
	        ps.setString(1,u.getfirstname());  
	        ps.setString(2,u.getlastname());  
	        ps.setString(3,u.getemail());  
	        ps.setString(4,u.gettel()); 
	        ps.setInt(5,id);
	        status=ps.executeUpdate(); 
	    }catch(Exception e){System.out.println(e);}  
	    return status;  
	}  
	public static String updatePassword(String a, String b,int id){  
	    int status=0;  
	    System.out.print(a);
	    System.out.print(b);
	    if (a.equals(b)) {
		    try{   Connection con=getConnection();  
		        PreparedStatement ps=con.prepareStatement(  
		"update user set password=? where user_id=?");  
		        ps.setString(1,a);  
		        ps.setInt(2,id);
		        status=ps.executeUpdate(); 
		    }catch(Exception e){System.out.println(e);}  
	    }
	    else {
	    	return "The two passwords don't match";
	    }
		    return "Password changed";  
	}  
	public static int delete(int u){  
	    int status=0;  
	    try{  
	        Connection con=getConnection();  
	        PreparedStatement ps=con.prepareStatement("delete from user where user_id=?");  
	        ps.setInt(1,u);  
	        status=ps.executeUpdate();  
	    }catch(Exception e){System.out.println(e);}  
	    
	    return status;  
	}  
	public static ArrayList<UserB> getAllRecords(){  
	    ArrayList<UserB> list=new ArrayList<UserB>();  
	      
	    try{  
	        Connection con=getConnection();  
	        PreparedStatement ps=con.prepareStatement("select * from user");  
	        ResultSet rs=ps.executeQuery();  
	        while(rs.next()){  
	            UserB u=new UserB();  	          
	            u.setId(rs.getInt("user_id"));  
	            u.setpassword(rs.getString("password"));  
	          
	            u.setlastname(rs.getString("lastname")); 
	            u.setfirstname(rs.getString("firstname"));  
	            
	            u.settel(rs.getString("tel"));  
	            u.setemail(rs.getString("email"));
	            list.add(u); 
	            
	        }  
	    }catch(Exception e){System.out.println(e);}  
	    return list;  
	}  
	public static UserB getRecordById(int id){  
	    UserB u=null;  
	    try{  
	        Connection con=getConnection();  
	        PreparedStatement ps=con.prepareStatement("select * from user where user_id=?");  
	        ps.setInt(1,id);  
	        ResultSet rs=ps.executeQuery();  
	        while(rs.next()){  
	            u= new UserB();  
	            u.setId(id); 
	            u.setfirstname(rs.getString("firstname"));  
	            u.setlastname(rs.getString("lastname"));  
	            u.setemail(rs.getString("email"));  
	            u.settel(rs.getString("tel"));  
	            u.setpassword(rs.getString("password"));  
	        }  
	    }catch(Exception e){System.out.println(e);}  
	    return u;  
	}  

}